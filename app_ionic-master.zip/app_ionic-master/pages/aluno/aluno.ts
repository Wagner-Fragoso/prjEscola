import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {AlunoServiceProvider} from '../../providers/aluno-service/aluno-service';

/**
 * Generated class for the AlunoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */


@Component({
  selector: 'page-aluno',
  templateUrl: 'aluno.html',
})
export class AlunoPage {
  alunos:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public alunoService: AlunoServiceProvider) {
      this.alunoService.getAlunos().subscribe(alunos => {
        this.alunos = alunos;
      })
    }

    ionViewDidEnter() {
    console.log(this.alunos);

  }

}
