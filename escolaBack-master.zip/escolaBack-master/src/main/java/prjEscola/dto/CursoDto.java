package prjEscola.dto;

public class CursoDto {

	public String Codigo;
	public String nome;
}
